# Prompts used — Project 17

1. Build a simple, plain HTML page for a campus event concept called TECHNOVA 2026. Include three content blocks: TECHNOVA 2026 / Three days of robotics, code and music. / Register now / Robotics · Hackathon · Music night; Chai and Co. / Fresh chai and snacks, all day. / See today's special / Masala chai ₹30 · Cold coffee ₹90 · Maska pav ₹45; Bright Path Classes / JEE and NEET batches near you. / Book a free demo / Small batches · Weekly tests · Doubt desk. Save as before.html. Keep the styling intentionally basic.

2. Apply a frontend design skill approach to redesign the same page. Preserve all original visible words and prices exactly. Improve hierarchy, typography, spacing, contrast, card design and responsive behaviour. Do not change the content or add marketing claims. Save as after.html.

3. Review the two files for content parity. Confirm that the same core headings, descriptions, button labels and item/feature phrases occur in both. Check mobile responsiveness at narrow widths and document three design changes with reasons.

4. Add a README with run instructions, a before/after comparison and a testing checklist. Keep all assets local and make the page work offline.
