# Design skill used — Impeccable / frontend-design-inspired

This project follows the assignment's instruction to apply a design skill (such as Impeccable or a frontend-design skill) after creating the plain page. The design direction is documented here; the skill itself is not claimed to have been installed or run automatically.

## Design brief
Redesign the same TECHNOVA 2026 page into a polished, responsive editorial event landing page. Preserve every user-facing word and price from `before.html`. Do not add or remove copy. Improve visual hierarchy, spacing, contrast, responsiveness and interaction feedback. Avoid generic template styling.

## Design decisions
1. **Visual hierarchy:** Large condensed-feeling hero typography, eyebrow label and clear content groupings make the event identity visible immediately.
2. **Card system:** Three distinct cards with numbered labels, consistent spacing, borders and hover feedback help users scan the festival, café and classes sections.
3. **Colour and contrast:** Deep plum background, soft lavender text and lime/pink accents create a coherent identity while keeping body text readable.
4. **Responsive layout:** Three columns on desktop collapse into a single column on mobile; hero and navigation also adapt.
5. **Interaction/accessibility:** Buttons have hover feedback, semantic sections are used, and reduced-motion preferences are respected.

## Content preservation
The same visible headings, descriptions, button labels and feature/price phrases are present in both HTML files. Layout labels and decorative navigation elements in the redesigned version are visual framing; core page copy is unchanged.
